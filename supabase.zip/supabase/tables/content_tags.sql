CREATE TABLE content_tags (
    id SERIAL PRIMARY KEY,
    content_id INTEGER NOT NULL,
    tag_id INTEGER NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);