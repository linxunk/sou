import { createClient } from '@supabase/supabase-js'

const supabaseUrl = "https://tnqgtwvyfeolbiwqytup.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRucWd0d3Z5ZmVvbGJpd3F5dHVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM3NTk3MTcsImV4cCI6MjA3OTMzNTcxN30.QakeYv0-jS_6KL_cZL0fNsssCdaJWHg4F_1GOp3a6K8";

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Types
export interface Content {
  id: number
  title: string
  description: string | null
  content_type: string | null
  category_id: number | null
  url: string | null
  file_url: string | null
  metadata: any
  created_at: string
  updated_at: string
}

export interface Category {
  id: number
  name: string
  description: string | null
  created_at: string
}

export interface Tag {
  id: number
  name: string
  created_at: string
}

export interface ContentTag {
  id: number
  content_id: number
  tag_id: number
  created_at: string
}
