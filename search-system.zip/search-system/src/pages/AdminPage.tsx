import { useState, useEffect } from 'react'
import { supabase, Content, Category, Tag } from '../lib/supabase'
import { 
  Lock, 
  Plus, 
  Edit2, 
  Trash2, 
  Save, 
  X,
  Home,
  BarChart3,
  FolderOpen,
  FileText
} from 'lucide-react'

const ADMIN_PASSWORD = '20160607yY!'

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  // 数据状态
  const [contents, setContents] = useState<Content[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [tags, setTags] = useState<Tag[]>([])
  const [contentTags, setContentTags] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  // UI 状态
  const [activeTab, setActiveTab] = useState<'contents' | 'categories' | 'stats'>('contents')
  const [editingContent, setEditingContent] = useState<Content | null>(null)
  const [showAddForm, setShowAddForm] = useState(false)
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null)

  // 表单状态
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    content_type: '文章',
    category_id: null as number | null,
    url: '',
    file_url: '',
    tag_ids: [] as number[]
  })

  // 统计数据
  const [stats, setStats] = useState({
    totalContents: 0,
    totalCategories: 0,
    totalTags: 0,
    recentSearches: [] as any[]
  })

  // 检查认证状态
  useEffect(() => {
    const authStatus = sessionStorage.getItem('admin_authenticated')
    if (authStatus === 'true') {
      setIsAuthenticated(true)
    }
  }, [])

  // 加载数据
  useEffect(() => {
    if (isAuthenticated) {
      loadData()
      loadStats()
    }
  }, [isAuthenticated])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      sessionStorage.setItem('admin_authenticated', 'true')
      setError('')
    } else {
      setError('密码错误')
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    sessionStorage.removeItem('admin_authenticated')
    setPassword('')
  }

  const loadData = async () => {
    setLoading(true)
    try {
      const { data: contentsData } = await supabase
        .from('contents')
        .select('*')
        .order('created_at', { ascending: false })
      setContents(contentsData || [])

      const { data: categoriesData } = await supabase
        .from('categories')
        .select('*')
      setCategories(categoriesData || [])

      const { data: tagsData } = await supabase
        .from('tags')
        .select('*')
      setTags(tagsData || [])

      const { data: contentTagsData } = await supabase
        .from('content_tags')
        .select('*')
      setContentTags(contentTagsData || [])
    } catch (error) {
      console.error('加载数据失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadStats = async () => {
    try {
      const { data: searchLogs } = await supabase
        .from('search_logs')
        .select('*')
        .order('search_time', { ascending: false })
        .limit(10)

      const { count: contentsCount } = await supabase
        .from('contents')
        .select('*', { count: 'exact', head: true })

      const { count: categoriesCount } = await supabase
        .from('categories')
        .select('*', { count: 'exact', head: true })

      const { count: tagsCount } = await supabase
        .from('tags')
        .select('*', { count: 'exact', head: true })

      setStats({
        totalContents: contentsCount || 0,
        totalCategories: categoriesCount || 0,
        totalTags: tagsCount || 0,
        recentSearches: searchLogs || []
      })
    } catch (error) {
      console.error('加载统计数据失败:', error)
    }
  }

  const handleAddContent = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const { data: newContent, error } = await supabase
        .from('contents')
        .insert({
          title: formData.title,
          description: formData.description || null,
          content_type: formData.content_type,
          category_id: formData.category_id,
          url: formData.url || null,
          file_url: formData.file_url || null
        })
        .select()
        .maybeSingle()

      if (error) throw error

      // 添加标签关联
      if (newContent && formData.tag_ids.length > 0) {
        const tagInserts = formData.tag_ids.map(tagId => ({
          content_id: newContent.id,
          tag_id: tagId
        }))
        await supabase.from('content_tags').insert(tagInserts)
      }

      setShowAddForm(false)
      resetForm()
      loadData()
      loadStats()
    } catch (error) {
      console.error('添加内容失败:', error)
      alert('添加失败，请重试')
    }
  }

  const handleUpdateContent = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingContent) return

    try {
      const { error } = await supabase
        .from('contents')
        .update({
          title: formData.title,
          description: formData.description || null,
          content_type: formData.content_type,
          category_id: formData.category_id,
          url: formData.url || null,
          file_url: formData.file_url || null,
          updated_at: new Date().toISOString()
        })
        .eq('id', editingContent.id)

      if (error) throw error

      // 更新标签关联
      await supabase
        .from('content_tags')
        .delete()
        .eq('content_id', editingContent.id)

      if (formData.tag_ids.length > 0) {
        const tagInserts = formData.tag_ids.map(tagId => ({
          content_id: editingContent.id,
          tag_id: tagId
        }))
        await supabase.from('content_tags').insert(tagInserts)
      }

      setEditingContent(null)
      resetForm()
      loadData()
    } catch (error) {
      console.error('更新内容失败:', error)
      alert('更新失败，请重试')
    }
  }

  const handleDeleteContent = async (id: number) => {
    try {
      // 先删除标签关联
      const { error: tagError } = await supabase
        .from('content_tags')
        .delete()
        .eq('content_id', id)
      
      if (tagError) {
        console.error('删除标签关联失败:', tagError)
      }
      
      // 再删除内容
      const { error } = await supabase
        .from('contents')
        .delete()
        .eq('id', id)
      
      if (error) throw error

      setDeleteConfirm(null)
      await loadData()
      await loadStats()
    } catch (error) {
      console.error('删除内容失败:', error)
      alert('删除失败，请重试')
    }
  }

  const startEdit = (content: Content) => {
    setEditingContent(content)
    const contentTagIds = contentTags
      .filter(ct => ct.content_id === content.id)
      .map(ct => ct.tag_id)
    
    setFormData({
      title: content.title,
      description: content.description || '',
      content_type: content.content_type || '文章',
      category_id: content.category_id,
      url: content.url || '',
      file_url: content.file_url || '',
      tag_ids: contentTagIds
    })
    setShowAddForm(true)
  }

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      content_type: '文章',
      category_id: null,
      url: '',
      file_url: '',
      tag_ids: []
    })
    setEditingContent(null)
  }

  const toggleTag = (tagId: number) => {
    setFormData(prev => ({
      ...prev,
      tag_ids: prev.tag_ids.includes(tagId)
        ? prev.tag_ids.filter(id => id !== tagId)
        : [...prev.tag_ids, tagId]
    }))
  }

  const getCategoryName = (categoryId: number | null) => {
    if (!categoryId) return '未分类'
    return categories.find(c => c.id === categoryId)?.name || '未分类'
  }

  const getContentTags = (contentId: number) => {
    const tagIds = contentTags
      .filter(ct => ct.content_id === contentId)
      .map(ct => ct.tag_id)
    return tags.filter(tag => tagIds.includes(tag.id))
  }

  // 登录界面
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center px-4">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">管理员登录</h1>
            <p className="text-gray-400">请输入管理员密码以继续</p>
          </div>

          <form onSubmit={handleLogin} className="bg-white rounded-xl shadow-xl p-8">
            <div className="mb-6">
              <label className="block text-gray-700 font-medium mb-2">
                密码
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                placeholder="请输入密码"
                required
              />
              {error && (
                <p className="mt-2 text-red-600 text-sm">{error}</p>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              登录
            </button>

            <a
              href="/"
              className="block text-center mt-4 text-gray-600 hover:text-gray-900"
            >
              返回主页
            </a>
          </form>
        </div>
      </div>
    )
  }

  // 管理界面
  return (
    <div className="min-h-screen bg-gray-50">
      {/* 头部 */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">管理后台</h1>
            <div className="flex gap-4">
              <a
                href="/"
                className="px-4 py-2 text-gray-700 hover:text-gray-900 flex items-center gap-2"
              >
                <Home className="w-4 h-4" />
                返回主页
              </a>
              <button
                onClick={handleLogout}
                className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700"
              >
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* 标签页 */}
        <div className="mb-6 flex gap-2">
          <button
            onClick={() => setActiveTab('contents')}
            className={`px-6 py-3 rounded-lg font-medium transition-colors flex items-center gap-2 ${
              activeTab === 'contents'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <FileText className="w-5 h-5" />
            内容管理
          </button>
          <button
            onClick={() => setActiveTab('categories')}
            className={`px-6 py-3 rounded-lg font-medium transition-colors flex items-center gap-2 ${
              activeTab === 'categories'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <FolderOpen className="w-5 h-5" />
            分类管理
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`px-6 py-3 rounded-lg font-medium transition-colors flex items-center gap-2 ${
              activeTab === 'stats'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <BarChart3 className="w-5 h-5" />
            统计信息
          </button>
        </div>

        {/* 内容管理 */}
        {activeTab === 'contents' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">内容列表</h2>
              <button
                onClick={() => {
                  setShowAddForm(true)
                  setEditingContent(null)
                  resetForm()
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                添加内容
              </button>
            </div>

            {/* 添加/编辑表单 */}
            {showAddForm && (
              <div className="bg-white rounded-xl shadow-sm border p-6 mb-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">
                    {editingContent ? '编辑内容' : '添加新内容'}
                  </h3>
                  <button
                    onClick={() => {
                      setShowAddForm(false)
                      resetForm()
                    }}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <form onSubmit={editingContent ? handleUpdateContent : handleAddContent}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        标题 *
                      </label>
                      <input
                        type="text"
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                        required
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        描述
                      </label>
                      <textarea
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                        rows={3}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        内容类型
                      </label>
                      <input
                        type="text"
                        value={formData.content_type}
                        onChange={(e) => setFormData({ ...formData, content_type: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        分类
                      </label>
                      <select
                        value={formData.category_id || ''}
                        onChange={(e) => setFormData({ ...formData, category_id: e.target.value ? Number(e.target.value) : null })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                      >
                        <option value="">选择分类</option>
                        {categories.map(cat => (
                          <option key={cat.id} value={cat.id}>{cat.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        URL 链接
                      </label>
                      <input
                        type="url"
                        value={formData.url}
                        onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                        placeholder="https://"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        文件 URL
                      </label>
                      <input
                        type="url"
                        value={formData.file_url}
                        onChange={(e) => setFormData({ ...formData, file_url: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                        placeholder="https://"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        标签
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {tags.map(tag => (
                          <button
                            key={tag.id}
                            type="button"
                            onClick={() => toggleTag(tag.id)}
                            className={`px-3 py-1 rounded-full text-sm transition-colors ${
                              formData.tag_ids.includes(tag.id)
                                ? 'bg-blue-600 text-white'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                            }`}
                          >
                            {tag.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
                    >
                      <Save className="w-5 h-5" />
                      {editingContent ? '保存' : '添加'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowAddForm(false)
                        resetForm()
                      }}
                      className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                    >
                      取消
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* 内容列表 */}
            {loading ? (
              <div className="text-center py-12">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">标题</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">分类</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">标签</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">创建时间</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {contents.map(content => (
                      <tr key={content.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="font-medium text-gray-900">{content.title}</div>
                          {content.description && (
                            <div className="text-sm text-gray-500 mt-1 line-clamp-2">
                              {content.description}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-700">
                          {getCategoryName(content.category_id)}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-1">
                            {getContentTags(content.id).map(tag => (
                              <span
                                key={tag.id}
                                className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                              >
                                {tag.name}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500">
                          {new Date(content.created_at).toLocaleDateString('zh-CN')}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => startEdit(content)}
                              className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setDeleteConfirm(content.id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* 删除确认对话框 */}
            {deleteConfirm && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white rounded-xl shadow-xl p-6 max-w-md w-full mx-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    确认删除
                  </h3>
                  <p className="text-gray-600 mb-6">
                    确定要删除这条内容吗？此操作无法撤销。
                  </p>
                  <div className="flex gap-3 justify-end">
                    <button
                      onClick={() => setDeleteConfirm(null)}
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                    >
                      取消
                    </button>
                    <button
                      onClick={() => handleDeleteContent(deleteConfirm)}
                      className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                    >
                      确认删除
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 分类管理 */}
        {activeTab === 'categories' && (
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">分类列表</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map(category => (
                <div
                  key={category.id}
                  className="p-4 border border-gray-200 rounded-lg hover:border-blue-500 transition-colors"
                >
                  <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
                  <p className="text-sm text-gray-600">{category.description}</p>
                  <p className="text-xs text-gray-400 mt-2">
                    {contents.filter(c => c.category_id === category.id).length} 条内容
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 统计信息 */}
        {activeTab === 'stats' && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-white rounded-xl shadow-sm border p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">总内容数</p>
                    <p className="text-3xl font-bold text-gray-900 mt-2">
                      {stats.totalContents}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <FileText className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">分类数</p>
                    <p className="text-3xl font-bold text-gray-900 mt-2">
                      {stats.totalCategories}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <FolderOpen className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">标签数</p>
                    <p className="text-3xl font-bold text-gray-900 mt-2">
                      {stats.totalTags}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">最近搜索</h2>
              {stats.recentSearches.length === 0 ? (
                <p className="text-gray-500">暂无搜索记录</p>
              ) : (
                <div className="space-y-3">
                  {stats.recentSearches.map((search, index) => (
                    <div
                      key={index}
                      className="flex justify-between items-center p-3 bg-gray-50 rounded-lg"
                    >
                      <div>
                        <p className="font-medium text-gray-900">{search.query}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(search.search_time).toLocaleString('zh-CN')}
                        </p>
                      </div>
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 text-sm rounded-full">
                        {search.result_count} 条结果
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
