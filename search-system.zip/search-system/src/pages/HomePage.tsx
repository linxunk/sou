import { useState, useEffect } from 'react'
import { supabase, Content, Category, Tag } from '../lib/supabase'
import { Search, SortAsc, SortDesc, Calendar, Tag as TagIcon } from 'lucide-react'

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [contents, setContents] = useState<Content[]>([])
  const [filteredContents, setFilteredContents] = useState<Content[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [tags, setTags] = useState<Tag[]>([])
  const [contentTags, setContentTags] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [sortBy, setSortBy] = useState<'relevance' | 'date' | 'title'>('relevance')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc')

  // 加载所有数据
  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setLoading(true)
    try {
      // 加载内容
      const { data: contentsData, error: contentsError } = await supabase
        .from('contents')
        .select('*')
        .order('created_at', { ascending: false })

      if (contentsError) throw contentsError
      setContents(contentsData || [])
      setFilteredContents(contentsData || [])

      // 加载分类
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('categories')
        .select('*')

      if (categoriesError) throw categoriesError
      setCategories(categoriesData || [])

      // 加载标签
      const { data: tagsData, error: tagsError } = await supabase
        .from('tags')
        .select('*')

      if (tagsError) throw tagsError
      setTags(tagsData || [])

      // 加载内容标签关联
      const { data: contentTagsData, error: contentTagsError } = await supabase
        .from('content_tags')
        .select('*')

      if (contentTagsError) throw contentTagsError
      setContentTags(contentTagsData || [])
    } catch (error) {
      console.error('加载数据失败:', error)
    } finally {
      setLoading(false)
    }
  }

  // 搜索功能
  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredContents(contents)
      return
    }

    const query = searchQuery.toLowerCase()
    const results = contents.filter(content => {
      const titleMatch = content.title.toLowerCase().includes(query)
      const descMatch = content.description?.toLowerCase().includes(query)
      
      // 检查标签匹配
      const contentTagIds = contentTags
        .filter(ct => ct.content_id === content.id)
        .map(ct => ct.tag_id)
      const contentTagNames = tags
        .filter(tag => contentTagIds.includes(tag.id))
        .map(tag => tag.name.toLowerCase())
      const tagMatch = contentTagNames.some(name => name.includes(query))

      return titleMatch || descMatch || tagMatch
    })

    // 记录搜索
    if (searchQuery.trim()) {
      supabase
        .from('search_logs')
        .insert({ query: searchQuery, result_count: results.length })
        .then()
    }

    setFilteredContents(results)
  }, [searchQuery, contents, contentTags, tags])

  // 排序功能
  useEffect(() => {
    const sorted = [...filteredContents].sort((a, b) => {
      let comparison = 0

      switch (sortBy) {
        case 'date':
          comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
          break
        case 'title':
          comparison = a.title.localeCompare(b.title)
          break
        case 'relevance':
        default:
          // 相关性排序基于标题匹配度
          const aMatch = a.title.toLowerCase().includes(searchQuery.toLowerCase()) ? 1 : 0
          const bMatch = b.title.toLowerCase().includes(searchQuery.toLowerCase()) ? 1 : 0
          comparison = bMatch - aMatch
          break
      }

      return sortOrder === 'asc' ? comparison : -comparison
    })

    setFilteredContents(sorted)
  }, [sortBy, sortOrder])

  // 获取分类名称
  const getCategoryName = (categoryId: number | null) => {
    if (!categoryId) return '未分类'
    const category = categories.find(c => c.id === categoryId)
    return category?.name || '未分类'
  }

  // 获取内容标签
  const getContentTags = (contentId: number) => {
    const tagIds = contentTags
      .filter(ct => ct.content_id === contentId)
      .map(ct => ct.tag_id)
    return tags.filter(tag => tagIds.includes(tag.id))
  }

  // 高亮搜索词
  const highlightText = (text: string, query: string) => {
    if (!query.trim()) return text
    
    const regex = new RegExp(`(${query})`, 'gi')
    const parts = text.split(regex)
    
    return parts.map((part, index) =>
      regex.test(part) ? (
        <mark key={index} className="bg-yellow-200 text-gray-900">
          {part}
        </mark>
      ) : (
        part
      )
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* 头部 */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              智能搜索系统
            </h1>
            <a
              href="/admin"
              className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              管理后台
            </a>
          </div>
        </div>
      </header>

      {/* 主要内容 */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* 搜索框 */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索内容、标签..."
              className="w-full pl-12 pr-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>
          
          {/* 搜索结果统计和排序 */}
          <div className="mt-4 flex justify-between items-center">
            <p className="text-gray-600">
              找到 <span className="font-semibold text-blue-600">{filteredContents.length}</span> 条结果
            </p>
            
            <div className="flex gap-2">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:border-blue-500"
              >
                <option value="relevance">相关性</option>
                <option value="date">日期</option>
                <option value="title">标题</option>
              </select>
              
              <button
                onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                className="px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                {sortOrder === 'asc' ? (
                  <SortAsc className="w-5 h-5" />
                ) : (
                  <SortDesc className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* 搜索结果 */}
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            <p className="mt-4 text-gray-600">加载中...</p>
          </div>
        ) : filteredContents.length === 0 ? (
          <div className="text-center py-12">
            <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">
              {searchQuery ? '未找到相关内容' : '暂无内容'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredContents.map((content) => {
              const contentTagList = getContentTags(content.id)
              
              return (
                <div
                  key={content.id}
                  className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between items-start mb-3">
                    <h2 className="text-xl font-semibold text-gray-900">
                      {highlightText(content.title, searchQuery)}
                    </h2>
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 text-sm rounded-full">
                      {getCategoryName(content.category_id)}
                    </span>
                  </div>
                  
                  {content.description && (
                    <p className="text-gray-600 mb-3">
                      {highlightText(content.description, searchQuery)}
                    </p>
                  )}
                  
                  {content.url && (
                    <a
                      href={content.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline mb-3 block"
                    >
                      {content.url}
                    </a>
                  )}
                  
                  <div className="flex justify-between items-center mt-4">
                    <div className="flex flex-wrap gap-2">
                      {contentTagList.map((tag) => (
                        <span
                          key={tag.id}
                          className="inline-flex items-center gap-1 px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                        >
                          <TagIcon className="w-3 h-3" />
                          {tag.name}
                        </span>
                      ))}
                    </div>
                    
                    <div className="flex items-center gap-2 text-gray-400 text-sm">
                      <Calendar className="w-4 h-4" />
                      {new Date(content.created_at).toLocaleDateString('zh-CN')}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}
